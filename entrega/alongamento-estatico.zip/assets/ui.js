// Interface da área de membros: troca de tema, barra de navegação e cartões que viram.
(function () {
  var root = document.documentElement;
  var plano = /[?&]export=1/.test(location.search);
  if (plano) return;

  /* ---- Tema claro/escuro (switch do Uiverse: Galahhad/strong-squid-82) ---- */
  var SWITCH =
    '<label class="theme-switch" aria-label="Alternar tema claro e escuro">' +
      '<input type="checkbox" class="theme-switch__checkbox">' +
      '<div class="theme-switch__container">' +
        '<div class="theme-switch__clouds"></div>' +
        '<div class="theme-switch__stars-container">' +
          '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 144 55" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M135.831 3.00688C135.055 3.85027 134.111 4.29946 133 4.35447C134.111 4.40947 135.055 4.85867 135.831 5.71123C136.607 6.55462 136.996 7.56303 136.996 8.72727C136.996 7.95722 137.172 7.25134 137.525 6.59129C137.886 5.93124 138.372 5.39954 138.98 5.00535C139.598 4.60199 140.268 4.39114 141 4.35447C139.88 4.2903 138.936 3.85027 138.16 3.00688C137.384 2.16348 136.996 1.16425 136.996 0C136.996 1.16425 136.607 2.16348 135.831 3.00688ZM31 23.3545C32.1114 23.2995 33.0551 22.8503 33.8313 22.0069C34.6075 21.1635 34.9956 20.1642 34.9956 19C34.9956 20.1642 35.3837 21.1635 36.1599 22.0069C36.9361 22.8503 37.8798 23.2903 39 23.3545C38.2679 23.3911 37.5976 23.602 36.9802 24.0053C36.3716 24.3995 35.8864 24.9312 35.5248 25.5913C35.172 26.2513 34.9956 26.9572 34.9956 27.7273C34.9956 26.563 34.6075 25.5546 33.8313 24.7112C33.0551 23.8587 32.1114 23.4095 31 23.3545ZM0 36.3545C1.11136 36.2995 2.05513 35.8503 2.83131 35.0069C3.6075 34.1635 3.99559 33.1642 3.99559 32C3.99559 33.1642 4.38368 34.1635 5.15987 35.0069C5.93605 35.8503 6.87982 36.2903 8 36.3545C7.26792 36.3911 6.59757 36.602 5.98015 37.0053C5.37155 37.3995 4.88644 37.9312 4.52481 38.5913C4.172 39.2513 3.99559 39.9572 3.99559 40.7273C3.99559 39.563 3.6075 38.5546 2.83131 37.7112C2.05513 36.8587 1.11136 36.4095 0 36.3545ZM56.8313 24.0069C56.0551 24.8503 55.1114 25.2995 54 25.3545C55.1114 25.4095 56.0551 25.8587 56.8313 26.7112C57.6075 27.5546 57.9956 28.563 57.9956 29.7273C57.9956 28.9572 58.172 28.2513 58.5248 27.5913C58.8864 26.9312 59.3716 26.3995 59.9802 26.0053C60.5976 25.602 61.2679 25.3911 62 25.3545C60.8798 25.2903 59.9361 24.8503 59.1599 24.0069C58.3837 23.1635 57.9956 22.1642 57.9956 21C57.9956 22.1642 57.6075 23.1635 56.8313 24.0069ZM81 25.3545C82.1114 25.2995 83.0551 24.8503 83.8313 24.0069C84.6075 23.1635 84.9956 22.1642 84.9956 21C84.9956 22.1642 85.3837 23.1635 86.1599 24.0069C86.9361 24.8503 87.8798 25.2903 89 25.3545C88.2679 25.3911 87.5976 25.602 86.9802 26.0053C86.3716 26.3995 85.8864 26.9312 85.5248 27.5913C85.172 28.2513 84.9956 28.9572 84.9956 29.7273C84.9956 28.563 84.6075 27.5546 83.8313 26.7112C83.0551 25.8587 82.1114 25.4095 81 25.3545ZM136 36.3545C137.111 36.2995 138.055 35.8503 138.831 35.0069C139.607 34.1635 139.996 33.1642 139.996 32C139.996 33.1642 140.384 34.1635 141.16 35.0069C141.936 35.8503 142.88 36.2903 144 36.3545C143.268 36.3911 142.598 36.602 141.98 37.0053C141.372 37.3995 140.886 37.9312 140.525 38.5913C140.172 39.2513 139.996 39.9572 139.996 40.7273C139.996 39.563 139.607 38.5546 138.831 37.7112C138.055 36.8587 137.111 36.4095 136 36.3545ZM101.831 49.0069C101.055 49.8503 100.111 50.2995 99 50.3545C100.111 50.4095 101.055 50.8587 101.831 51.7112C102.607 52.5546 102.996 53.563 102.996 54.7273C102.996 53.9572 103.172 53.2513 103.525 52.5913C103.886 51.9312 104.372 51.3995 104.98 51.0053C105.598 50.602 106.268 50.3911 107 50.3545C105.88 50.2903 104.936 49.8503 104.16 49.0069C103.384 48.1635 102.996 47.1642 102.996 46C102.996 47.1642 102.607 48.1635 101.831 49.0069Z" fill="currentColor"></path></svg>' +
        '</div>' +
        '<div class="theme-switch__circle-container"><div class="theme-switch__sun-moon-container"><div class="theme-switch__moon">' +
          '<div class="theme-switch__spot"></div><div class="theme-switch__spot"></div><div class="theme-switch__spot"></div>' +
        '</div></div></div>' +
      '</div>' +
    '</label>';

  var header = document.querySelector("header.top .wrap");
  if (header) {
    var barra = document.createElement("div");
    barra.className = "topbar";
    var voltar = header.querySelector('a[href="membros.html"]');
    if (voltar) barra.appendChild(voltar); else barra.appendChild(document.createElement("span"));
    barra.insertAdjacentHTML("beforeend", SWITCH);
    header.insertBefore(barra, header.firstChild);
    var cb = barra.querySelector(".theme-switch__checkbox");
    cb.checked = root.getAttribute("data-theme") === "dark";
    cb.addEventListener("change", function () {
      var t = cb.checked ? "dark" : "light";
      root.setAttribute("data-theme", t);
      try { localStorage.setItem("ae:tema", t); } catch (e) {}
    });
  }

  /* ---- Barra de navegação com dicas (themrsami/bad-bear-23) ---- */
  var ICONES = {
    inicio: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>',
    buscar: '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
    guias: '<rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect>',
    agenda: '<rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
    progresso: '<path d="M21 21H4.6c-1.1 0-2-.9-2-2V3"></path><path d="M19 8l-7 6-4-4-4 4"></path>'
  };
  var noMembros = !!document.getElementById("q");
  var ITENS = [
    ["inicio", "Início", "membros.html"],
    ["buscar", "Buscar", "membros.html#busca"],
    ["guias", "Guias", "membros.html#modulos"],
    ["agenda", "Agenda", "#agenda"],
    ["progresso", "Progresso", "membros.html#progresso"]
  ];
  // a agenda fica no fim de cada guia com exercícios (não na lista inicial)
  if (!document.getElementById("agenda")) ITENS = ITENS.filter(function (it) { return it[0] !== "agenda"; });
  var wrap = document.createElement("div");
  wrap.className = "ae-nav-wrap";
  wrap.innerHTML = '<nav class="ae-nav" aria-label="Navegação"><div class="itens">' + ITENS.map(function (it, n) {
    return '<div class="grupo"><a class="botao' + (noMembros && n === 0 ? " ativo" : "") + '" href="' + it[2] + '" data-ir="' + it[0] + '" aria-label="' + it[1] + '">' +
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONES[it[0]] + '</svg></a>' +
      '<div class="dica"><div class="caixa">' + it[1] + '<div class="seta"><i></i></div></div></div></div>';
  }).join("") + '</div></nav>';
  document.body.appendChild(wrap);
  document.body.classList.add("com-nav");

  function ir(alvo) {
    var q = document.getElementById("q");
    if (alvo === "inicio") { window.scrollTo({ top: 0, behavior: "smooth" }); return; }
    if (alvo === "buscar") {
      var b = document.getElementById("busca"); if (b) b.scrollIntoView({ behavior: "smooth", block: "center" });
      if (q) setTimeout(function () { q.focus({ preventScroll: true }); }, 350); return;
    }
    if (q && q.value) { q.value = ""; q.dispatchEvent(new Event("input")); }
    var el = document.getElementById({ guias: "modulos", agenda: "agenda", progresso: "progresso" }[alvo]);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  if (!noMembros) {
    wrap.addEventListener("click", function (e) {
      var a = e.target.closest('a[href="#agenda"]'); if (!a) return;
      e.preventDefault(); var ag = document.getElementById("agenda");
      if (ag) ag.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }
  if (noMembros) {
    wrap.addEventListener("click", function (e) {
      var a = e.target.closest("a[data-ir]"); if (!a) return;
      e.preventDefault(); e.stopPropagation(); ir(a.getAttribute("data-ir"));
    });
    var h = location.hash.replace("#", "");
    var mapa = { busca: "buscar", modulos: "guias", agenda: "agenda", progresso: "progresso" };
    if (mapa[h]) setTimeout(function () { ir(mapa[h]); }, 900);
  }

  /* ---- Cartões que viram (toque ou Enter) + concluir ---- */
  var lista = document.getElementById("cards");
  if (lista) {
    lista.addEventListener("click", function (e) {
      if (e.target.closest(".conc")) return;
      var f = e.target.closest(".flip"); if (f) { f.classList.toggle("virado"); }
    });
    lista.addEventListener("keydown", function (e) {
      if (e.key !== "Enter" && e.key !== " ") return;
      var f = e.target.classList && e.target.classList.contains("flip") ? e.target : null;
      if (f) { e.preventDefault(); f.classList.toggle("virado"); }
    });
    lista.addEventListener("change", function (e) {
      var i = e.target; if (!i.matches || !i.matches(".conc input")) return;
      if (window.AE) {
        AE.marcar(i.getAttribute("data-k"), i.checked);
        if (window.renderAgenda) renderAgenda(); // atualiza "você concluiu X de Y" na agenda do fim do guia
      }
    });
  }
})();
